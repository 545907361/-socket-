/*
 *  fs/partitions/amiga.h
 */

int amiga_partition(struct parsed_partitions *state);

