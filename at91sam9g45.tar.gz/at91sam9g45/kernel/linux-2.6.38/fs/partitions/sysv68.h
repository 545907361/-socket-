extern int sysv68_partition(struct parsed_partitions *state);
